package dev.fxcte.creepyware.util;

public
class PacketUtil$ArrayOutOfBoundsException
        extends RuntimeException {
}

