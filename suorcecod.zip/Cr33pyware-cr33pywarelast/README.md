# Cr33pyware

## This is official Cr33pyware's Repo
##### uh i made this public now because it got leaked a few weeks ago (or a month) i forgor 💀  and 
##### im trying to rember 💠  here is the buildable src code and latest jar 

## Questions

### Is this a rat?
#### uh no, and if you don't believe us just check it yourself moron

### Will it update it future?
#### no it won't. This is discontinued 


##### Main Developers
` _Fxcte `
` Kuro_Here `
` Faxhax ` 
` SSLWasTaken `
